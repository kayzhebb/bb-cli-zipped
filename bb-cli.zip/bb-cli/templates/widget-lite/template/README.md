# ${widget.name}
${widget.description}

## Information
| Name       |  ${widget.name} |
|------------|---|
| Version    | ${widget.version}  |
| Bundle     | DBP |
| Authors      | ${widget.author}  |
| Icon       | ![icon](icon.png) |
| Status     | N/A |

## Preferences

## Events

## Custom Components

## Develop Standalone

```bash
cd <widget-path>
bower install && bblp start
```

## Requirements

### User Requirements

### Business Requirements

## References
