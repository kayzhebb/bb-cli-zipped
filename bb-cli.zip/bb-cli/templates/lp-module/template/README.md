# ${module.name}

${module.description}

## Information

| name                  | version           | bundle           |
| ----------------------|:-----------------:| ----------------:|
| ${module.name}        | ${module.version} |                  |
