# ${widget.name}
${widget.description}

## Information

| name                  | version           |
| ----------------------|:-----------------:|
| ${widget.name}        | ${widget.version} |


## Dependencies
* angular ~1.4.7
* ionic ~1.4.7

## Dev Dependencies
* mock ^1.0.8
* angular-mocks ~1.4.7

## Preferences
- List of widget preferences

## Events
- List of event the widget publishes/subscribes

## Custom Components
- list of widget custom components (if any)

## Develop Standalone

```bash
git clone <repo-url> && cd <widget-path>
bower install && bblp start
```


## Requirements

### User Requirements

### Business Requirements

## References
