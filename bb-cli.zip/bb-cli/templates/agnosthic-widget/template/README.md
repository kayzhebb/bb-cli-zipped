# generator-widget-agnostic
Widget template for Backbase CXP without any dependancies
